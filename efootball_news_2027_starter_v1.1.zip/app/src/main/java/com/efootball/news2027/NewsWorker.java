package com.efootball.news2027;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.List;

public class NewsWorker extends Worker {
    public NewsWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c,p); }

    @NonNull @Override public Result doWork() {
        try {
            List<NewsItem> news=NewsRepository.fetch();
            if(news.isEmpty()) return Result.success();
            SharedPreferences sp=getApplicationContext().getSharedPreferences("news",0);
            String latest=news.get(0).title;
            String old=sp.getString("latest","");
            if(!latest.equals(old)) {
                sp.edit().putString("latest",latest).apply();
                notifyNews(news.get(0));
            }
            return Result.success();
        } catch(Exception e) { return Result.retry(); }
    }

    private void notifyNews(NewsItem n) {
        Context c=getApplicationContext();
        if(android.os.Build.VERSION.SDK_INT>=33 &&
           ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(android.os.Build.VERSION.SDK_INT>=26)
            nm.createNotificationChannel(new NotificationChannel("news","أخبار eFootball",NotificationManager.IMPORTANCE_DEFAULT));
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,"news")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("خبر جديد في eFootball")
            .setContentText(n.title)
            .setAutoCancel(true);
        nm.notify(2027,b.build());
    }
}

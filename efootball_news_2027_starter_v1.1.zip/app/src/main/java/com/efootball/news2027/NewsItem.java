package com.efootball.news2027;

public class NewsItem {
    public String title, link, image, source, date;
    public NewsItem(String title, String link, String image, String source, String date) {
        this.title = title; this.link = link; this.image = image; this.source = source; this.date = date;
    }
}

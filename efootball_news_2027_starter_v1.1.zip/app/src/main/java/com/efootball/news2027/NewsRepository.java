package com.efootball.news2027;

import android.text.Html;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NewsRepository {
    // Google News RSS gives continuously updated results. Prefer official KONAMI links when available.
    public static final String FEED =
        "https://news.google.com/rss/search?q=eFootball%20KONAMI&hl=en-US&gl=US&ceid=US:en";

    public static List<NewsItem> fetch() throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(FEED).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent","eFootballNews2027/1.1");
        InputStream in=c.getInputStream();
        XmlPullParser p=Xml.newPullParser(); p.setInput(in,"UTF-8");
        List<NewsItem> out=new ArrayList<>();
        String title="", link="", desc="", pub="", source="";
        boolean item=false, insideTitle=false, insideLink=false, insideDesc=false, insidePub=false, insideSource=false;
        String image="";
        int event;
        while((event=p.next())!=XmlPullParser.END_DOCUMENT) {
            if(event==XmlPullParser.START_TAG) {
                String n=p.getName();
                if("item".equalsIgnoreCase(n)) { item=true; title=link=desc=pub=source=image=""; }
                else if(item && "title".equalsIgnoreCase(n)) insideTitle=true;
                else if(item && "link".equalsIgnoreCase(n)) insideLink=true;
                else if(item && "description".equalsIgnoreCase(n)) insideDesc=true;
                else if(item && "pubDate".equalsIgnoreCase(n)) insidePub=true;
                else if(item && "source".equalsIgnoreCase(n)) insideSource=true;
                else if(item && ("media:content".equalsIgnoreCase(n) || "media".equalsIgnoreCase(n))) {
                    for(int i=0;i<p.getAttributeCount();i++) {
                        if("url".equalsIgnoreCase(p.getAttributeName(i))) image=p.getAttributeValue(i);
                    }
                }
            } else if(event==XmlPullParser.TEXT) {
                if(insideTitle) title=p.getText();
                if(insideLink) link=p.getText();
                if(insideDesc) desc=p.getText();
                if(insidePub) pub=p.getText();
                if(insideSource) source=p.getText();
            } else if(event==XmlPullParser.END_TAG) {
                String n=p.getName();
                if("title".equalsIgnoreCase(n)) insideTitle=false;
                else if("link".equalsIgnoreCase(n)) insideLink=false;
                else if("description".equalsIgnoreCase(n)) insideDesc=false;
                else if("pubDate".equalsIgnoreCase(n)) insidePub=false;
                else if("source".equalsIgnoreCase(n)) insideSource=false;
                else if("item".equalsIgnoreCase(n)) {
                    item=false;
                    String clean=Html.fromHtml(desc).toString().trim();
                    // Google News RSS often doesn't expose a stable image. The adapter leaves it blank if none exists.
                    out.add(new NewsItem(title.trim(),link.trim(),image,source.trim(),pub.trim()));
                }
            }
        }
        in.close(); c.disconnect();
        return out;
    }
}

package com.efootball.news2027;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private final List<NewsItem> items=new ArrayList<>();
    private NewsAdapter adapter;
    private TextView status;
    private ProgressBar progress;

    @Override public void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        progress=findViewById(R.id.progress);
        RecyclerView list=findViewById(R.id.newsList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter=new NewsAdapter(items); list.setAdapter(adapter);

        if(android.os.Build.VERSION.SDK_INT>=33 &&
           ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},77);

        load();
        PeriodicWorkRequest work=new PeriodicWorkRequest.Builder(NewsWorker.class, 15, TimeUnit.MINUTES).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "efootball_news_check", androidx.work.ExistingPeriodicWorkPolicy.KEEP, work);
    }

    private void load() {
        progress.setVisibility(View.VISIBLE); status.setText("جاري تحديث الأخبار...");
        new Thread(() -> {
            try {
                List<NewsItem> result=NewsRepository.fetch();
                runOnUiThread(() -> {
                    items.clear(); items.addAll(result); adapter.notifyDataSetChanged();
                    progress.setVisibility(View.GONE);
                    status.setText("تم تحديث الأخبار تلقائيًا • اضغط على الخبر لفتحه");
                });
            } catch(Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    status.setText("تعذر جلب الأخبار. تحقق من الإنترنت.");
                });
            }
        }).start();
    }
}

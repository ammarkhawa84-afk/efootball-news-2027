package com.efootball.news2027;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.Holder> {
    private final List<NewsItem> items;
    public NewsAdapter(List<NewsItem> items) { this.items = items; }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p, int v) {
        return new Holder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_news, p, false));
    }

    @Override public void onBindViewHolder(@NonNull Holder h, int pos) {
        NewsItem n = items.get(pos);
        h.headline.setText(n.title);
        h.source.setText(n.source + (n.date.isEmpty() ? "" : " • " + n.date));
        Glide.with(h.image.getContext()).load(n.image).centerCrop().into(h.image);
        h.itemView.setOnClickListener(v -> {
            try { v.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(n.link))); }
            catch (Exception ignored) {}
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        ImageView image; TextView headline, source;
        Holder(View v) {
            super(v);
            image=v.findViewById(R.id.image);
            headline=v.findViewById(R.id.headline);
            source=v.findViewById(R.id.source);
        }
    }
}
